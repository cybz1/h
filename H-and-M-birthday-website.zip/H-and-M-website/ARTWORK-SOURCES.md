The current Paris couple scene, character poses and kittens were generated with the built-in image generation tool using the supplied references. The final Paris edit gives the boy rounded shorter curls while retaining the pixel scene.

# Artwork sources

## Artwork used by the current website

- `paris-together-short-curls.png`: custom Paris pixel scene created using the built-in image generation tool and user-supplied references. Final edit prompt: change only the boy's hair to rounded dark curls around the ears with modest nape length and no curls down the back; preserve glasses, characters, scene, palette and composition.
- `her-pixel-poses.png`: custom three-pose character sheet made using the built-in image generation tool and the user's portrait reference, then edited into chunkier pixel art.
- `letter-kittens-pixel.png`: cream and grey pixel kittens made using the built-in image generation tool and refined into chunkier pixel art.
- Country flags: FlagCDN via Flagpedia. https://flagpedia.net/download/api
- Map geometry: Natural Earth 1:110m Admin 0 countries. https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_110m_admin_0_countries.geojson
- Pixel font: VT323 via Google Fonts.

## Retained earlier artwork

- Earlier generated cottage and portrait images, and the previous longer-haired Paris scene, remain as editable alternatives.
- Previous Paris background: StockCake, Starry Parisian Night. https://stockcake.com/fr/i/starry-parisian-night_4008797_1542510 — CC0 under https://stockcake.com/info/license .
- Previous girl game sprite: josepharaoh99, Girl RPG Sprite Sheet. https://opengameart.org/content/girl-rpg-sprite-sheet — CC0.
- Previous pixel cat sheet: Noob, 2D cat sprite. https://opengameart.org/content/2d-cat-sprite — CC0.
